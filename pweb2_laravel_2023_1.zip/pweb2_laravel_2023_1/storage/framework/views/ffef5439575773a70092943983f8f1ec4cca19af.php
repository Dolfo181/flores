<?php $__env->startSection('conteudo'); ?>
    <?php
        if (!empty($fornecedor->id)) {
            $route = route('fornecedor.update', $fornecedor->id);
        } else {
            $route = route('fornecedor.store');
        }
    ?>
<?php $__env->startSection('tituloPagina', 'Formulário Usuário'); ?>
<h1>Formulário fornecedores</h1>

<div class="col">
    <div class="row">
        <form action='<?php echo e($route); ?>' method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(!empty($fornecedor->id)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <input type="hidden" name="id"
                value="<?php if(!empty(old('id'))): ?> <?php echo e(old('id')); ?> <?php elseif(!empty($fornecedor->id)): ?> <?php echo e($fornecedor->id); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" /><br>
            <div class="col-3">
                <label class="form-label">Nome</label><br>
                <input type="text" class="form-control" name="nome"
                    value="<?php if(!empty(old('nome'))): ?> <?php echo e(old('nome')); ?> <?php elseif(!empty($fornecedor->nome)): ?> <?php echo e($fornecedor->nome); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" /><br>
            </div>
            <div class="col-3">
                <label class="form-label">Telefone</label><br>
                <input type="text" class="form-control" name="telefone"
                    value="<?php if(!empty(old('telefone'))): ?> <?php echo e(old('telefone')); ?> <?php elseif(!empty($fornecedor->telefone)): ?> <?php echo e($fornecedor->telefone); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" /><br>
            </div>
            <div class="col-3">
                <label class="form-label">E-mail</label><br>
                <input type="email" class="form-control" name="email"
                    value="<?php if(!empty(old('email'))): ?> <?php echo e(old('email')); ?> <?php elseif(!empty($fornecedor->email)): ?> <?php echo e($fornecedor->email); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" /><br>
            </div>
           
            <?php
                $nome_imagem = !empty($fornecedor->imagem) ? $fornecedor->imagem : 'sem_imagem.jpg';
            ?>
            <div class="col-6">
                <br>
                <img class="img-thumbnail" src="/storage/<?php echo e($nome_imagem); ?>" width="300px" />
                <br><br>
                <input type="file" class="form-control" name="imagem" /><br>
            </div>
            <button class="btn btn-success" type="submit">
                <i class="fa-solid fa-save"></i> Salvar
            </button>
            <a href='<?php echo e(route('usuario.index')); ?>' class="btn btn-primary"><i class="fa-solid fa-arrow-left"></i>
                Voltar</a> <br><br>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb2_laravel_2023_1-main\resources\views/fornecedorForm.blade.php ENDPATH**/ ?>