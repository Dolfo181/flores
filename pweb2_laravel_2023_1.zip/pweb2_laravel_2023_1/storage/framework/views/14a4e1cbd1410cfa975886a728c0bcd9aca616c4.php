<?php $__env->startSection('conteudo'); ?>
<?php $__env->startSection('tituloPagina', 'Princípal'); ?>
<div class="col" style="padding: 5%">
    <div class="row">
        <div class="col-sm-6 mb-3 mb-sm-0">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Titulo 01</h5>
                    <p class="card-text">Descrição aqui</p>
                    <a href="#" class="btn btn-primary">Clique aqui</a>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Titulo 02</h5>
                    <p class="card-text">Descrição aqui</p>
                    <a href="#" class="btn btn-primary">Clique aqui</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb2_laravel_2023_1-main\resources\views/base/dashboard.blade.php ENDPATH**/ ?>