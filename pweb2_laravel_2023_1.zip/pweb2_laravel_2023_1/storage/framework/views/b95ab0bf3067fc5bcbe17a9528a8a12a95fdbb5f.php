    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Sis ABC</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown active">
                        <a class="nav-link dropdown-toggle" aria-current="page" href="#" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Cadastros
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(url('/usuario')); ?>">Usuário</a></li>
                            <li><a class="dropdown-item" href="#">Item 01</a></li>
                            <li><a class="dropdown-item" href="#">Item 02</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Item 01</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Item 01</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled">Item 03</a>
                    </li>
                </ul>
            </div>
            <div style="margin-right: 50px;">
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Logar')); ?></a>
                    </li>
                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrar-se')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <i class='fas fa-user'></i> <?php echo e(Auth::user()->name); ?>

                        </button>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="#"> <i class='fas fa-user-cog'></i> Perfil</a>
                            <a class="dropdown-item" href="#"><i class='fas fa-cog'></i> Configurações</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class='fas fa-sign-out-alt'></i> <?php echo e(__('Logout')); ?></a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>

                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </nav>

<?php /**PATH C:\laragon\www\pweb2_laravel_2023_1\resources\views/base/menu.blade.php ENDPATH**/ ?>