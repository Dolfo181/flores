<?php $__env->startSection('conteudo'); ?>
    <?php
        if (!empty($produto->id)) {
            $route = route('produto.update', $produto->id);
        } else {
            $route = route('produto.store');
        }
    ?>
<?php $__env->startSection('tituloPagina', 'Formulário produto'); ?>
<h1>Formulário produto</h1>

<div class="col">
    <div class="row">
        <form action='<?php echo e($route); ?>' method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(!empty($produto->id)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <input type="hidden" name="id"
                value="<?php if(!empty(old('id'))): ?> <?php echo e(old('id')); ?> <?php elseif(!empty($produto->id)): ?> <?php echo e($produto->id); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" /><br>
            <div class="col-3">
                <label class="form-label">Nome</label><br>
                <input type="text" class="form-control" name="nome"
                    value="<?php if(!empty(old('nome'))): ?> <?php echo e(old('nome')); ?> <?php elseif(!empty($produto->nome)): ?> <?php echo e($produto->nome); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" /><br>
            </div>
            <div class="col-3">
                <label class="form-label">Valor</label><br>
                <input type="text" class="form-control" name="valor"
                    value="<?php if(!empty(old('valor'))): ?> <?php echo e(old('valor')); ?> <?php elseif(!empty($produto->valor)): ?> <?php echo e($produto->valor); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" /><br>
            </div>
            <div class="col-3">
                <label class="form-label">Espécie</label><br>
                <input type="email" class="form-control" name="email"
                    value="<?php if(!empty(old('email'))): ?> <?php echo e(old('email')); ?> <?php elseif(!empty($produto->email)): ?> <?php echo e($produto->email); ?> <?php else: ?> <?php echo e(''); ?> <?php endif; ?>" /><br>
            </div>

            <?php
                $nome_imagem = !empty($produto->imagem) ? $produto->imagem : 'sem_imagem.jpg';
            ?>
            <div class="col-6">
                <br>
                <img class="img-thumbnail" src="/storage/<?php echo e($nome_imagem); ?>" width="300px" />
                <br><br>
                <input type="file" class="form-control" name="imagem" /><br>
            </div>
            <button class="btn btn-success" type="submit">
                <i class="fa-solid fa-save"></i> Salvar
            </button>
            <a href='<?php echo e(route('produto.index')); ?>' class="btn btn-primary"><i class="fa-solid fa-arrow-left"></i>
                Voltar</a> <br><br>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb2_laravel_2023_1\resources\views/ProdutosForm.blade.php ENDPATH**/ ?>