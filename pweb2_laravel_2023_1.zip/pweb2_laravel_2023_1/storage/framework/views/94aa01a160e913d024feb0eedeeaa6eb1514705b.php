<?php $__env->startSection('conteudo'); ?>
<?php $__env->startSection('tituloPagina', 'Listagem de Fornecedores'); ?>
<h1>Listagem de Fornecedores</h1>
<form action="<?php echo e(route('fornecedor.search')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-2">
            <select name="campo" class="form-select">
                <option value="nome">Nome</option>
                <option value="telefone">Telefone</option>
            </select>
        </div>
        <div class="col-4">
            <input type="text" class="form-control" placeholder="Pesquisar" name="valor" />
        </div>
        <div class="col-6">
            <button class="btn btn-primary" type="submit">
                <i class="fa-solid fa-magnifying-glass"></i> Buscar
            </button>
            <a class="btn btn-success" href='<?php echo e(action('App\Http\Controllers\FornecedorController@create')); ?>'><i
                    class="fa-solid fa-plus"></i> Cadastrar</a>
        </div>
    </div>
</form>
<table class="table table-striped table-hover">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Nome Fornecedor</th>
            <th scope="col">CNPJ</th>
            <th scope="col">Email</th>
            <th scope="col">Tipo de produto</th>
            <th scope="col"></th>
            <th scope="col"></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $fornecedor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $nome_imagem = !empty($item->imagem) ? $item->imagem : 'sem_imagem.jpg';
            ?>
            <tr>
                <td scope='row'><?php echo e($item->id); ?></td>
                <td><?php echo e($item->nome); ?></td>
                <td><?php echo e($item->telefone); ?></td>
                <td><?php echo e($item->email); ?></td>
                <td><?php echo e($item->categoria->nome ?? ''); ?></td>
                <td><img src="/storage/<?php echo e($nome_imagem); ?>" width="100px" class="img-thumbnail" /> </td>
                <td><a href="<?php echo e(action('App\Http\Controllers\FornecedorController@edit', $item->id)); ?>"><i
                            class='fa-solid fa-pen-to-square' style='color:orange;'></i></a></td>
                <td>
                    <form method="POST"
                        action="<?php echo e(action('App\Http\Controllers\FornecedorController@destroy', $item->id)); ?>">
                        <input type="hidden" name="_method" value="DELETE">
                        <?php echo csrf_field(); ?>
                        <button type="submit" onclick='return confirm("Deseja Excluir?")' style='all: unset;'><i
                                class='fa-solid fa-trash' style='color:red;'></i>
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb2_laravel_2023_1\resources\views/fornecedorList.blade.php ENDPATH**/ ?>